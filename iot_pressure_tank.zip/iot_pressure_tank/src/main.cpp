/*
 * ESP32 Sensor Publisher + Leak Alert LED
 * ----------------------------------------------------------------------------
 * Matches the system diagram:
 *   [Air Pressure] \
 *   [Airflow]       >--> ESP32 --(MQTT/TLS)--> EMQX Broker --> Node.js Subscriber
 *   [Temperature]  /                                           --> WebSocket --> React Dashboard
 *                                                              --> HTTP API  --> Database
 *
 * Bidirectional MQTT:
 *   ESP32 publishes sensor data  --> sensor/data
 *   ESP32 subscribes to commands <-- sensor/command  (leak alert LED control)
 *
 * Instead of reading real sensors, this sketch simulates all three values
 * with a smooth "random walk" so the data looks realistic on the dashboard.
 * Later, replace the simulate*() functions with real sensor reads.
 */

#include <Arduino.h>

#include "board_cfg.h"
#include "hw_funcs.h"

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// ---------------------------------------------------------------------------
// WiFi credentials
// ---------------------------------------------------------------------------
const char* WIFI_SSID     = "ZENBOOK";
const char* WIFI_PASSWORD = "nimdinu123";

// ---------------------------------------------------------------------------
// EMQX Cloud broker settings
// ---------------------------------------------------------------------------
const char* MQTT_SERVER = "ha372312.ala.us-east-1.emqxsl.com";
const int   MQTT_PORT   = 8883;                  // 8883 = MQTT over TLS
const char* MQTT_USER   = "sliit";  // created in EMQX Authentication
const char* MQTT_PASS   = "sliit";

// Topic the Node.js backend subscribes to (the "Sensor Data" arrow in the diagram)
const char* MQTT_TOPIC_PUBLISH = "sensor/data";

// Topic the ESP32 subscribes to for commands from the backend (leak alerts)
const char* MQTT_TOPIC_COMMAND = "sensor/command";

// Identifies this device in the JSON payload (useful if you add more ESP32s later)
const char* DEVICE_ID = "esp32-01";

// How often to publish a new reading (milliseconds)
const unsigned long PUBLISH_INTERVAL_MS = 5000;

// ---------------------------------------------------------------------------
// Network objects
// ---------------------------------------------------------------------------
WiFiClientSecure espClient;       // TLS-capable TCP client
PubSubClient     client(espClient); // MQTT client running on top of it

// ---------------------------------------------------------------------------
// Simulated sensor state (current values, updated every cycle)
// ---------------------------------------------------------------------------
float airPressure = 1013.25f;  // hPa  (standard sea-level pressure)
float airflow     = 120.0f;    // L/min
float temperature = 25.0f;     // degrees Celsius
SensorValues airSensorValues;

// ---------------------------------------------------------------------------
// Leak detection state (received from backend via MQTT)
// ---------------------------------------------------------------------------
bool leakDetected = false;

// ---------------------------------------------------------------------------
// MQTT callback – handles incoming messages on subscribed topics
// ---------------------------------------------------------------------------
// Called whenever a message arrives on "sensor/command".
// Expected JSON: {"device_id":"esp32-01","leakDetected":true}
// We parse the leakDetected boolean and set the LED accordingly.
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  // Build a string from the payload bytes
  char json[256];
  unsigned int copyLen = (length < sizeof(json) - 1) ? length : sizeof(json) - 1;
  memcpy(json, payload, copyLen);
  json[copyLen] = '\0';

  Serial.print("Received on [");
  Serial.print(topic);
  Serial.print("]: ");
  Serial.println(json);

  // Simple JSON parsing
  // Check for leakDetected
  char* leakKey = strstr(json, "\"leakDetected\"");
  if (leakKey != NULL) {
    char* colonPos = strchr(leakKey, ':');
    if (colonPos != NULL) {
      if (strstr(colonPos, "true") != NULL) {
        leakDetected = true;
        set_alert_led(500);  // Blink LED every 500 ms
        Serial.println(">>> LEAK ALERT: LED ON");
      } else if (strstr(colonPos, "false") != NULL) {
        leakDetected = false;
        set_alert_led(0);  // LED OFF
        Serial.println(">>> LEAK CLEAR: LED OFF");
      }
    }
  }

  // Check for targetPressure
  char* targetKey = strstr(json, "\"targetPressure\"");
  if (targetKey != NULL) {
    char* colonPos = strchr(targetKey, ':');
    if (colonPos != NULL) {
      float newTarget = atof(colonPos + 1);
      if (newTarget > 0.0) {
        set_target_pressure(newTarget);
      }
    }
  }
}

// ---------------------------------------------------------------------------
// WiFi
// ---------------------------------------------------------------------------
void setupWifi() {
  Serial.println();
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  // Block until the router gives us an IP address
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

// ---------------------------------------------------------------------------
// MQTT
// ---------------------------------------------------------------------------
void reconnectMqtt() {
  // Keep trying until the broker accepts the connection
  while (!client.connected()) {
    // Make sure WiFi is still up before touching MQTT
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("WiFi lost, reconnecting...");
      setupWifi();
    }

    Serial.print("Connecting to EMQX broker... ");

    // Each client needs a unique ID, otherwise the broker kicks the older one.
    // The ESP32's eFuse MAC address is unique per chip.
    String clientId = "ESP32Client-";
    clientId += String((uint32_t)ESP.getEfuseMac(), HEX);

    if (client.connect(clientId.c_str(), MQTT_USER, MQTT_PASS)) {
      Serial.println("connected!");

      // Subscribe to the command topic so we can receive leak alerts
      client.subscribe(MQTT_TOPIC_COMMAND);
      Serial.print("Subscribed to: ");
      Serial.println(MQTT_TOPIC_COMMAND);
    } else {
      // rc codes: -2 = network/TLS failure, 4 = bad credentials, 5 = not authorized
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" - retrying in 5 seconds");
      delay(5000);
    }
  }
}

// Build the JSON payload and publish it to the broker
void publishSensorData() {
  char payload[256];

  // Single JSON message containing all three readings + leak status.
  // The Node.js subscriber can parse this and forward it over WebSocket / HTTP.
  snprintf(payload, sizeof(payload),
           "{\"device_id\":\"%s\",\"pressure\":%.2f,\"airflow\":%.2f,"
           "\"temperature\":%.2f,\"leakDetected\":%s,\"uptime_ms\":%lu}",
           DEVICE_ID, airPressure, airflow, temperature,
           leakDetected ? "true" : "false", millis());

  Serial.print("Publishing to [");
  Serial.print(MQTT_TOPIC_PUBLISH);
  Serial.print("]: ");
  Serial.println(payload);

  // publish() returns false if the message could not be sent
  if (!client.publish(MQTT_TOPIC_PUBLISH, payload)) {
    Serial.println("Publish failed!");
  }
}

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);

  init_hardware();

  setupWifi();

  // NOTE: setInsecure() skips TLS certificate validation. The connection is
  // still encrypted, but the server's identity is not verified. This is fine
  // for testing. For production, load the EMQX CA certificate instead:
  //   espClient.setCACert(emqx_ca_cert);
  espClient.setInsecure();

  client.setServer(MQTT_SERVER, MQTT_PORT);
  client.setCallback(mqttCallback);  // Register the callback for incoming messages

  // Print instructions to Serial Monitor
  Serial.println();
  Serial.println("========================================");
  Serial.println("  AirTrace ESP32 Sensor Publisher");
  Serial.println("========================================");
  Serial.println();
}

void loop() {

  if(xQueueReceive(sensor_value_queue, &airSensorValues, 0) == pdTRUE) {
    // Update the global sensor values with the latest readings
    airPressure = airSensorValues.pressure * 10000.0;
    airflow     = airSensorValues.airflow * 0.06;
    temperature = airSensorValues.temperature;
  }

  // Make sure we are connected to the broker
  if (!client.connected()) {
    reconnectMqtt();
  }

  // Let the MQTT library handle keep-alive pings and incoming packets
  // This also dispatches the callback for any received messages
  client.loop();

  // Publish a new reading every PUBLISH_INTERVAL_MS without blocking the loop
  static unsigned long lastPublish = 0;
  if (millis() - lastPublish >= PUBLISH_INTERVAL_MS) {
    lastPublish = millis();


    publishSensorData();  // 2. Send them to EMQX
  }
}
