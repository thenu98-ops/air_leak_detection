#ifndef _HW_FUNCS_H_
#define _HW_FUNCS_H_

#include "board_cfg.h"

typedef struct {
    float temperature;
    float pressure;
    float airflow;
} SensorValues;

extern QueueHandle_t sensor_value_queue;

void init_hardware();

void set_alert_led(int time);
void set_target_pressure(float pressure_mpa);





#endif


