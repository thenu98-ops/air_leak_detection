#include <Arduino.h>
#include "hw_funcs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include <Wire.h>

QueueHandle_t sensor_value_queue;

class LedTimer {
  private:
    uint8_t pin;
    volatile bool ledState;
    hw_timer_t * timer;
    static LedTimer* instance;

    static void IRAM_ATTR onTimer() {
      if (instance != NULL) {
        instance->toggleLed();
      }
    }
    void IRAM_ATTR toggleLed() {
      ledState = !ledState;
      digitalWrite(pin, ledState);
    }

  public:
    LedTimer() {
      timer = NULL;
      ledState = false;
    }

    void init(uint8_t pinNumber) {
      pin = pinNumber;
      pinMode(pin, OUTPUT);
      digitalWrite(pin, LOW);
      
      instance = this;
      timer = timerBegin(0, 80, true);
      timerAttachInterrupt(timer, &onTimer, true);
    }

    void set(uint32_t timeMs) {
      if (timer != NULL) {
        timerAlarmWrite(timer, timeMs * 1000, true); 
        timerAlarmEnable(timer);
      }
    }

    void clear() {
      if (timer != NULL) {
        timerAlarmDisable(timer);
        ledState = false;
        digitalWrite(pin, LOW);
      }
    }
};
LedTimer* LedTimer::instance = NULL;

class FlowSensor {
  private:
    const float PULSES_PER_ML = 4.38;

    uint8_t pin;
    volatile uint32_t pulseCount;
    
    uint32_t lastCalcTime;
    uint32_t lastPulseCount;

    static void IRAM_ATTR isr(void* arg) {
      FlowSensor* instance = static_cast<FlowSensor*>(arg);
      instance->pulseCount++;
    }

  public:
    FlowSensor() {
      pulseCount = 0;
      lastCalcTime = 0;
      lastPulseCount = 0;
    }

    void init(uint8_t pinNumber) {
      pin = pinNumber;
      pinMode(pin, INPUT_PULLUP); 
      
      pulseCount = 0;
      lastPulseCount = 0;
      lastCalcTime = millis();

      attachInterruptArg(digitalPinToInterrupt(pin), isr, this, RISING);
    }

    uint32_t getCount() {
      noInterrupts();
      uint32_t currentCount = pulseCount;
      interrupts();
      return currentCount;
    }

    float getVolume() {
      uint32_t currentCount = getCount();
      if (PULSES_PER_ML <= 0.0) return 0.0; 
      return (float)currentCount / PULSES_PER_ML;
    }

    float getFlowRate() {
      uint32_t currentTime = millis();
      uint32_t timeDelta = currentTime - lastCalcTime;
      
      if (timeDelta == 0) return 0.0; 

      uint32_t currentCount = getCount();
      uint32_t pulsesDelta = currentCount - lastPulseCount;

      lastPulseCount = currentCount;
      lastCalcTime = currentTime;

      float ml = (float)pulsesDelta / PULSES_PER_ML;
      float seconds = (float)timeDelta / 1000.0;
      
      return ml / seconds;
    }

    void clear() {
      noInterrupts();
      pulseCount = 0;
      interrupts();
      
      lastPulseCount = 0;
      lastCalcTime = millis();
    }
};

class XDB401 {
  private:
    uint8_t i2cAddress;
    float maxPressureMpa;
    const uint8_t DEFAULT_ADDRESS = 0x7F;

  public:
    XDB401(float maxPressure = 1.2) {
      i2cAddress = DEFAULT_ADDRESS;
      maxPressureMpa = maxPressure;
    }

    bool init(int sdaPin, int sclPin) {
      Wire.begin(sdaPin, sclPin);
      Wire.setClock(100000); 

      Wire.beginTransmission(i2cAddress);
      byte error = Wire.endTransmission();

      if (error == 0) {
        Serial.println("XDB401 Sensor successfully found.");
        return true;
      } else {
        Serial.printf("Error finding XDB401. Code: %d\n", error);
        return false;
      }
    }

    bool get_data(float* pressure_mpa, float* temperature_c) {
      // 1. Send command 0x0A to register 0x30 to trigger acquisition
      Wire.beginTransmission(i2cAddress);
      Wire.write(0x30);
      Wire.write(0x0A);
      if (Wire.endTransmission() != 0) {
        return false;
      }

      // 2. Wait for acquisition to complete
      delay(100); 

      // 3. Read 5 bytes of data starting from register 0x06
      Wire.beginTransmission(i2cAddress);
      Wire.write(0x06); 
      Wire.endTransmission(false);

      Wire.requestFrom(i2cAddress, (uint8_t)5);

      if (Wire.available() == 5) {
        // Read pressure bytes (Registers 0x06, 0x07, 0x08)
        uint8_t p_high = Wire.read();
        uint8_t p_mid  = Wire.read();
        uint8_t p_low  = Wire.read();
        
        // Read temperature bytes (Registers 0x09, 0x0A)
        uint8_t t_high = Wire.read();
        uint8_t t_low  = Wire.read();

        // --- Pressure Calculation (24-bit) ---
        uint32_t raw_pressure = ((uint32_t)p_high * 65536) + ((uint32_t)p_mid * 256) + p_low;
        float cal_pdata2;
        
        if (raw_pressure > 8388608) {
            cal_pdata2 = (float)(raw_pressure - 16777216) / 8388608.0;
        } else {
            cal_pdata2 = (float)raw_pressure / 8388608.0;
        }
        
        *pressure_mpa = cal_pdata2 * maxPressureMpa;

        // --- Temperature Calculation (16-bit) ---
        uint32_t raw_temp = ((uint32_t)t_high * 256) + t_low;
        
        if (raw_temp > 32768) {
            *temperature_c = (float)(raw_temp - 65536) / 256.0;
        } else {
            *temperature_c = (float)raw_temp / 256.0;
        }

        return true;
      }

      return false;
    }
};

void pump_motor_init(){
    pinMode(PUMP_OUT_PIN, OUTPUT);
    digitalWrite(PUMP_OUT_PIN, LOW);
}

void pump_motor_set(bool state){
    digitalWrite(PUMP_OUT_PIN, state);
}

LedTimer alert_led;
FlowSensor flow_sensor;
XDB401 pressure_sensor;

float current_target_pressure = 0.8; // Default 0.8 MPa

void set_target_pressure(float pressure_mpa) {
    current_target_pressure = pressure_mpa;
    Serial.printf(">>> Target pressure updated to: %.2f MPa\n", current_target_pressure);
}

void set_alert_led(int time){
    if(time > 0){
        alert_led.set(time);
    } else {
        alert_led.clear();
    }
}

void sensor_read_task(void* arg){
    float pressure, temperature, volume, flow_rate;
    SensorValues values;

    while(1){
        flow_rate = flow_sensor.getFlowRate();
        volume = flow_sensor.getVolume();
        pressure_sensor.get_data(&pressure, &temperature);

        values.airflow = flow_rate;
        values.pressure = pressure;
        values.temperature = temperature;

        // --- Pump Control Logic ---
        if (pressure >= current_target_pressure) {
            pump_motor_set(false); // Turn OFF
        } else if (pressure <= (current_target_pressure - 0.15)) { // 0.15 MPa hysteresis
            pump_motor_set(true);  // Turn ON
        }

        if(sensor_value_queue != NULL){
            xQueueSend(sensor_value_queue, &values, 0);
        } else {
            Serial.println("Sensor value queue is NULL");
        }

        // debug
        printf("Flow Rate: %.2f mL/s, Volume: %.2f mL\n", flow_rate, volume);
        printf("Pressure: %.3f MPa, Target: %.2f MPa, Temp: %.2f C\n", pressure, current_target_pressure, temperature);

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void init_hardware() {
    alert_led.init(ALERT_LED_PIN);
    flow_sensor.init(FLOW_METER_PULSE_PIN);
    pump_motor_init();
    pressure_sensor.init(I2C_SDA_PIN, I2C_SCL_PIN);

    sensor_value_queue = xQueueCreate(5, sizeof(SensorValues));
    if(sensor_value_queue == NULL){
      Serial.println("Failed to create sensor value queue");
      alert_led.set(100);
    }
    xTaskCreate(sensor_read_task, "SensorReadTask", 2048, NULL, 1, NULL);

    pump_motor_set(true);
}

