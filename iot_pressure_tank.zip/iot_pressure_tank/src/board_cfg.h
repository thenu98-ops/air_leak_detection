#ifndef _BOARD_CFG_H_
#define _BOARD_CFG_H_


#define I2C_SCL_PIN 0
#define I2C_SDA_PIN 1

#define FLOW_METER_PULSE_PIN 4

#define ALERT_LED_PIN 7

#define PUMP_OUT_PIN 10


#endif